import styled from 'styled-components';

// Navigation styles
export const StyledNav = styled.nav`
    .headerCont {
        background: #f1f1f1;
        padding-bottom:1em;
        margin-bottom: 40px;
        list-style: none;
        a {
            text-decoration: none;
            padding: 2em;
            font-size: 2.0em;
            font-weight: bold;
            color: black;
            transition: 0.3s;
            text-align:center;
        }
        a:hover{
            color:#DD3835;
            text-decoration: underline;
            transition: 0.3s;
        }
        h1 {
            padding-bottom: 20px;
            color: green;
        }
        .shop-logo {
            width:90px;
            height: auto;
        }
    }
`;

//h1 styles
export const Title = styled.h1`
    font-size: 1.8em;
    color: black;
    display:inline;
`;

// Button Styles
export const Button = styled.button`
    color: white;
    background: grey;
    border: 1px solid #3f3a46;
    font-size: 1em;
    margin: 1em;
    padding: 0.8em 1.2em;
    border-radius: 5px;
    &:hover {
        background-color: #fff;
        color: black;
        transition: 0.5s;
        cursor: pointer;
    }
`;


// Wrapper
export const Wrapper = styled.div`
    display: flex;
    align-items: center;
    align-content: center;
    flex-direction: column;
    flex-flow: row wrap;
    justify-content: center;
    background: #fffff;
    color: black;
    text-align: center;
`;





