import React from 'react';
import { Link } from 'react-router-dom';
import { StyledNav } from '../styles/Styling';
import shop_logo_big from "../images/shop_logo_big.png";

function Nav() {
    return (
        <StyledNav>
            <div className='headerCont'>
            <img
                className="shop-logo"
                src={shop_logo_big.img ? shop_logo_big.img : shop_logo_big}
                alt={shop_logo_big.title}
            />
                <h1>Victoria's Shop</h1>
                <ul>
                    <Link to="/">
                        Shop
                    </Link>
                    <Link to="/manage-items">
                        Admin
                    </Link>
                </ul>
            </div>
            
        </StyledNav>
    )
}

export default Nav